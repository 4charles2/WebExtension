export class Chomeur {
    constructor(login, password, codePostal){
        this.login = login;
        this.password = password;
        this.codePostal = codePostal;
    }
}
